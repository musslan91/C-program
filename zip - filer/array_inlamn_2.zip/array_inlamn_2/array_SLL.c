#include "array_SLL.h"

array_SLL *create_SLL( int size ) {
}
int destroy_SLL( array_SLL *array ) {
}
int insert_SLL( array_SLL *array, double value ) {
}
double lookup_SLL( array_SLL *array, int index ) {
}
int find_SLL( array_SLL *array, double value ) {
}
