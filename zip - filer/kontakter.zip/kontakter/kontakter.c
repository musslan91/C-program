#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct _person2_S {
   char *namn;
   int alder;
} person2;

person2 p1, p2, kontakt[10];

int main(void) {
   int ix, alder;
   char namn[64], alderstr[64];

   printf("Välkommen till kontakter!\n");
   for(ix = 0; ix < 3; ix++) {
      printf("Mata in kontakt nr %d\n", ix);
      printf("ange namn:"); fflush(stdout);
      fgets(namn,64,stdin);
      namn[strlen(namn)-1] = '\0';
      // kontakt[ix].namn = namn;
      // 1. skapa ett nytt utrymme för sträng
      // och lägg i kontakt[ix].namn
      kontakt[ix].namn = malloc(strlen(namn));
      // 2. kopiera över det som finns i namn
      // till vårt nya utrymme
      strcpy(kontakt[ix].namn, namn);
      printf("ange ålder:"); fflush(stdout);
      fgets(alderstr,64,stdin);
      alder = atoi(alderstr);
      kontakt[ix].alder = alder;
      printf("namn: %s ålder: %d\n", 
             kontakt[ix].namn, kontakt[ix].alder);
   }
   printf("====\n");
   for(ix = 0; ix < 3; ix++) {
      printf("namn: %s ålder: %d\n", 
             kontakt[ix].namn, kontakt[ix].alder);
   }

   return 0;
}