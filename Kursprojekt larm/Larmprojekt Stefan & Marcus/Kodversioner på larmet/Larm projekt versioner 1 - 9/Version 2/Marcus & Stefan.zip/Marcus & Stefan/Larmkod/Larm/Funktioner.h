int msensor1=13;         //Set the digital 13 to PIR
int ledgreen=12;        //Set the digital 12 to LED
int ledred=11;           //Set the digital 11 to LED
int larm;

#include <Keypad.h>

int password(){

  char* password = "1234"; //Vårt lösenord
  int position = 0;
  const byte ROWS = 4;
  const byte COLS = 4;

  char keys[ROWS][COLS] = {
    {'1','2','3','A'},
    {'4','5','6','B'},
    {'7','8','9','C'},
    {'*','0','#','D'},
  };

  byte rowPins[ROWS] = {9, 8, 7, 6};
  byte colPins[COLS] = {5, 4, 3, 2};

  if(keys != password){
  Serial.println("Wrong password");
  }
  if(keys == password){
    Serial.println("Correct");
    sensoron();  
  }
 if(keys == password){
  Serial.println("Correct");
  sensoroff();  
}
int sensor1(){
    if(digitalRead(msensor1)==LOW && larm == false){ //Detecting whether the body movement information
    digitalWrite(ledgreen,HIGH);//LED OFF
    delay(500);
    Serial.println("Inget alarm !!!");
  }
   if(digitalRead(msensor1)==HIGH && larm == true){
   digitalWrite(ledgreen,LOW);
   delay(250);
   digitalWrite(ledred,HIGH);//LED ON
   Serial.println("Alarm !!!");
   }
}

sensoroff(){
  if(larm == true){
    Serial.println("Deactivated");
}
}

sensoron(){

  if(larm == false){
    Serial.println("Activated");
  }
}
}

