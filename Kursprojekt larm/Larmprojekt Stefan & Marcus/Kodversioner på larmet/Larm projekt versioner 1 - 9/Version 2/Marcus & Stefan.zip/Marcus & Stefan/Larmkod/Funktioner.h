int msensor1=13;         //Set the digital 13 to PIR
int msensor2=12;         //Set the digital 12 to PIR
int ledgreen=11;        //Set the digital 12 to LED
int ledred=10;           //Set the digital 11 to LED

int sensor1(){
if(digitalRead(msensor1)==LOW)//Detecting whether the body movement information
  {
    digitalWrite(ledgreen,HIGH);//LED OFF
    delay(1000);
    digitalWrite(ledred,LOW);
    Serial.println("Inget alarm !!!");
  }else
 
    digitalWrite(ledred,HIGH);//LED ON
    Serial.println("Alarm !!!");
   
   if(digitalRead(ledred)==HIGH){
   delay(1000);
   digitalWrite(ledgreen,LOW);
   }
  }
int sensor2(){
if(digitalRead(msensor2)==LOW)//Detecting whether the body movement information
  {
    digitalWrite(ledgreen,HIGH);//LED OFF
    delay(1000);
    digitalWrite(ledred,LOW);
    Serial.println("Inget alarm !!!");
  }else
  {
    digitalWrite(ledred,HIGH);//LED ON
    Serial.println("Alarm !!!");
   
   if(digitalRead(ledred)==HIGH){
   delay(1000);
   digitalWrite(ledgreen,LOW); 
  }  
}
}
