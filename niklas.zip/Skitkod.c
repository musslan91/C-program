#include <stdio.h>
#include <stdlib.h>

int main(){

	system("chcp 1252");
	system("cls");

	int niklas;

	printf("Skriv siffra, bara 1 som funkar:\n\n");
	scanf("%d", &niklas);


	if(niklas == 1){

		printf(" Niklas är homosexuel!\n");
	}

	else if(niklas != 1){

		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		printf(" Niklas är homosexuel!\n");
		
	}

return 0;
}