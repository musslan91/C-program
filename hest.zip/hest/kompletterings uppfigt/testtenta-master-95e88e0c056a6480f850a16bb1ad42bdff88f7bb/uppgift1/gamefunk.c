game_game();
gamestart();
hitflee();
enemyhpstr();
calc();
