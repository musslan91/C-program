#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "gamefunk.h"

int main () {

    gamestart();
    game_game();
}

/* Option to either hit enemy or flee*/
