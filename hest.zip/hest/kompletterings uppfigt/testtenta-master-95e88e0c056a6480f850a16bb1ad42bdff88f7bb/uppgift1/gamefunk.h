
/*Bools to close loops*/
bool playerTurn;
bool menuLoop;

/*Player Character*/
int playerHP;
int playerStr;
char playerName[50];

/*Enemy character*/
int enemyHP;
int enemyStr;

/*Ints to save menu options*/
int selection;
int battleSelection;

/* Prints out the status of the player*/
/* Main with random seed and entering of player name*/

int gamestart()
{
    //  char enemyName[10];
    srand(time(NULL));

    printf("\n");
    printf("Enter Your Name: ");
    scanf("%s", &playerName);
    system("cls");

    selection = 0;
    menuLoop = true;
}

int game_game()
{
    while(menuLoop)
    {

        printf("Welcome to the Arena: %s, Make your choice" , playerName);
        playerStr = (rand() % (22 + 1 - 8)) + 4;
        //Power();
        playerHP = (rand() % (22 +1 - 8)) +4;//HitPoints();
        printf("\nYour Health and Strenght are displayed below, choose your enemy!");
        printf("\nHP: %d", playerHP);
        printf("\nStr: %d \n", playerStr);
        //		PlayerStatus();

        printf("\n1. Battle Diablo");
        printf("\n2. Battle Mephisto");
        printf("\n3. Rest\n");
        printf("\n4. Exit\n");
        scanf("%d", &selection);
}

        int hitflee()
        {
            printf("\n1. Hit");
            printf("\n2. Flee\n");
            scanf("%d", &battleSelection);
        }

        int enemyhpstr()
        {
            printf("\nHP: %d", enemyHP);
            printf("\nStr: %d \n", enemyStr);
            //	EnemyStatus();
        }

        int calc()
        {
            enemyHP = (rand() % (22 +1 - 8)) +4;//HitPoints();
            enemyStr = (rand() % (22 + 1 - 8)) + 4;//Power();
        }

        switch (selection) {

            case 1:

            playerTurn = false;
            char enemyName[]= "Diablo";
            //	enemyName[]= "Diablo";

            calc();

            printf("You will now battle %s" , enemyName);

            int enemyhpstr();

            if (playerStr >= enemyStr){

                playerTurn = true;

            }

            while (playerHP > 0 && enemyHP > 0 ) {

                if(playerTurn){
                    int battleSelection;

                    hitflee();

                    switch (battleSelection){
                        case 1:

                        printf("\n%s hit enemy and damages him with %d damage\n" , playerName  , playerStr);
                        enemyHP = enemyHP - playerStr;

                        printf("Enemy have %d %d HP remaining\n" , enemyName, enemyHP);
                        playerTurn = false;
                        if (enemyHP <=0)
                        printf("Congratulations %s you have WON!" , playerName);
                        menuLoop = false;
                        break;

                        case 2:

                        gamestart();

                        break;

                        default:

                        printf("\nError try again");

                        break;
                    }

                    //		HitEnemy();
                }
                else{
                    printf("\nEnemy hit %s and damages him with %d",playerName,  enemyStr);
                    playerHP = playerHP - enemyStr;

                    printf("\n%s: %d HP remaining",playerName, playerHP);
                    playerTurn = true;
                }
                //		Turn();

            }

            if(playerHP <=0 ){
                printf("\nYou died, GAME OVER! ");
                menuLoop = false;
            }
            //			Diablo();

            break;

            case 2:

            playerTurn = false;
            char enemyName2[]= "Mephisto";
            calc();

            printf("\n You will now battle" , enemyName2);

            enemyhpstr();

            if (playerStr >= enemyStr){

                playerTurn = true;
                playerStr <=5;
                playerStr*playerStr;

            }

            while (playerHP > 0 && enemyHP > 0 ) {

                if(playerTurn){
                    int battleSelection;

                    hitflee();

                    switch (battleSelection){
                        case 1:

                        printf("\n%s hit enemy and damages him with %d damage\n" , playerName  , playerStr);
                        enemyHP = enemyHP - playerStr;

                        printf("Enemy have %d %d HP remaining\n" , enemyName2, enemyHP);
                        playerTurn = false;
                        if (enemyHP <=0)
                        printf("Congratulations %s you have WON!" , playerName);
                        menuLoop = false;
                        break;

                        case 2:

                        gamestart();

                        break;

                        default:

                        printf("\nError try again");

                        break;
                    }

                    //		HitEnemy();
                }
                else{
                    printf("\nEnemy hit %s and damages him with %d",playerName,  enemyStr);
                    playerHP = playerHP - enemyStr;

                    printf("\n%s: %d HP remaining",playerName, playerHP);
                    playerTurn = true;
                }
                //		Turn();

            }

            if(playerHP <=0 ){
                printf("\nYou died, GAME OVER!");
                menuLoop = false;
            }
            //			Mephisto();

            case 3:

            playerHP = 20;

            if (playerStr < 10) {

                playerStr++;

            }

            break;

            case 4:

            menuLoop = false;
            exit(0);

            break;

            default:

            printf("\nError try again");

            break;
        }
    }
}
