int funk_omkrets ();
int funk_area ();
int funk_volym ();
