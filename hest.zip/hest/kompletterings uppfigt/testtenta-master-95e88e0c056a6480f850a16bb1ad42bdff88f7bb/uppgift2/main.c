#include <stdio.h>
#include <stdlib.h>
#include "funktioner.h"

int main ()
{
            printf("Tryck 1 för att räkna omkrets\n");
            printf("Tryck 2 för att räkna area\n");
            printf("Tryck 3 för att räkna volym\n");

            int val;
            scanf("%d", &val);
            system("cls");
            printf("Du har valt menyval: %d\n", val);

            if(val == 1)
            {
                funk_omkrets();
                return main();
            }
            else if(val >= 4){
                printf("Du har skrivit in ett felaktigt menyval. Börja om.\n");
                return main();
            }

            if(val == 2)
            {
                funk_area();
                return main();
            }
            else if(val >= 4){
                printf("Du har skrivit in ett felaktigt menyval. Börja om.\n");
                return main();
            }

            if(val == 3)
            {
                funk_volym();
                return main();

            }
            else if(val >= 4){
                printf("Du har skrivit in ett felaktigt menyval. Börja om.\n");
                return main();
            }
            return 0;
        }
