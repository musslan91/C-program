#include "funktioner.h"
// ====================================//====================================
// Omkrets
int funk_omkrets ()
{
    while(1)
    {
    int omkrets;
    int tal1,tal2,tal3,tal4;

    printf("\nDu har valt omkrets, skriv in fyra värden:\n");

    printf("Skriv tal 1:\n");
    scanf("%d", &tal1);

    if(tal1 <= 0 || tal1 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }
    // ====================================//====================================
    printf("Skriv tal 2:\n");
    scanf("%d", &tal2);

    if(tal2 <= 0 || tal2 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }
    // ====================================//====================================
    printf("Skriv tal 3:\n");
    scanf("%d", &tal3);

    if(tal3 <= 0 || tal3 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }
    // ====================================//====================================
    printf("Skriv tal 4:\n");
    scanf("%d", &tal4);

    if(tal4 <= 0 || tal4 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }

    omkrets = tal1 + tal2 + tal3 + tal4;

    printf("Omkretsen är: %d\n", omkrets);
}
}
// ====================================//====================================
// Area
int x ()
{
    int area;
    int tal1,tal2;
    printf("\nDu har valt area, skriv in bredd och längd:\n");

    // ====================================//====================================
    printf("Skriv bredd:\n");
    scanf("%d", &tal1);

    if(tal1 <= 0 || tal1 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");

    }
    // ====================================//====================================

    printf("Skriv längd:\n");
    scanf("%d", &tal2);

    if(tal2 <= 0 || tal2 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");

    }

    area = tal1 * tal2;

    printf("Arean är: %d\n", area);
}
// ====================================//====================================
// Volym
int funk_volym ()
{
    int volym;
    int tal1,tal2,tal3;
    printf("\nDu har valt volym, skriv in längden, bredden, höjden:\n");

    printf("Skriv längd:\n");
    scanf("%d", &tal1);

    if(tal1 <= 0 || tal1 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }
    // ====================================//====================================
    printf("Skriv bredd:\n");
    scanf("%d", &tal2);

    if(tal2 <= 0 || tal2 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }
    // ====================================//====================================
    printf("Skriv höjden:\n");
    scanf("%d", &tal3);

    if(tal3 <= 0 || tal3 >= 1000)
    {
        printf("Börja om, mata in ett nytt värde mellan 0 - 1000:\n");
    }

    volym = tal1 * tal2 * tal3;

    printf("Volymen är: %d\n", volym);
}
// ====================================//====================================
