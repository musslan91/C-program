#include "unity.h"
#include "testfunktioner.h"

void test_omkrets(void)
{
TEST_ASSERT_EQUAL_FLOAT(70, omkrets_test(40, 10, 10, 10));
TEST_ASSERT_EQUAL_FLOAT(120, omkrets_test(60, 20, 20, 20));
TEST_ASSERT_EQUAL_FLOAT(100, omkrets_test(50, 10, 20, 20));
// TEST_ASSERT_EQUAL_FLOAT(10, funk_omkrets(10, 10, 10, 10,)); // Testfall ska bli felaktikt
}

void test_area(void)
{
TEST_ASSERT_EQUAL_FLOAT(100, area_test(10, 10));
TEST_ASSERT_EQUAL_FLOAT(40, area_test(10, 4));
TEST_ASSERT_EQUAL_FLOAT(200, area_test(10, 20));
// TEST_ASSERT_EQUAL_FLOAT(40, funk_area(10, 20)); // Testfall ska bli felaktikt
}

void test_volym(void)
{
TEST_ASSERT_EQUAL_FLOAT(125, volym_test(5, 5, 5));
TEST_ASSERT_EQUAL_FLOAT(1000, volym_test(10, 10, 10));
TEST_ASSERT_EQUAL_FLOAT(27, volym_test(3, 3 , 3));
// TEST_ASSERT_EQUAL_FLOAT(77, funk_volym(3, 3 , 3)); // Testfall ska bli felaktikt
}

int main(void)
{
UNITY_BEGIN();
RUN_TEST(test_omkrets);
RUN_TEST(test_area);
RUN_TEST(test_volym);
return UNITY_END();
}
