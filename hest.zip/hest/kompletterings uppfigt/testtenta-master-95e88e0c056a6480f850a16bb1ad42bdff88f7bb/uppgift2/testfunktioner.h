float omkrets_test(float value_1, float value_2, float value_3, float value_4);
float area_test(float value_1, float value_2);
float volym_test(float value_1, float value_2, float value_3);
