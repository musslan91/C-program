#include "testfunktioner.h"

float omkrets_test(float value_1, float value_2, float value_3, float value_4)
    {
    return ((value_1) + (value_2) + (value_3) + (value_4));
    }

float area_test(float value_1, float value_2)
        {
        return ((value_1) * (value_2));
        }

float volym_test(float value_1, float value_2, float value_3)
    {
    return ((value_1) * (value_2) * (value_3));
    }
