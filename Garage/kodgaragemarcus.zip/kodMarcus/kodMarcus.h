  bool up;
  bool down;
  const int sensor = A3;// Dörrsensorn
  const int doordown = 10;//Dörr nere lägesbrytare
  const int dooropen = 11;//Dörr öppen lägesbrytare
  const int doorbuttondown = 12;//Knapp utanför garaget för att trycka ner garaget.
  const int doorbuttonup = 13;//Knapp utanför för att öppna garaget.
  
 int motorupp(){
  if (digitalRead(dooropen) != true){
   digitalWrite(9, HIGH);
   delayMicroseconds(1000);
   digitalWrite(9, LOW);
   delay(50);
   digitalWrite(9, HIGH);
   delayMicroseconds(1000);
   digitalWrite(9, LOW);
   delay(50);
   digitalWrite(9, HIGH);
   delayMicroseconds(1000);
   digitalWrite(9, LOW);
   delay(50);
   }
 }

     
  int motorner(){
   if (digitalRead(doordown) == false){
     digitalWrite(9, HIGH);
     delayMicroseconds(2000);
     digitalWrite(9, LOW);
     delay(50);
     digitalWrite(9, HIGH);
     delayMicroseconds(2000);
     digitalWrite(9, LOW);
     delay(50);
     digitalWrite(9, HIGH);
     delayMicroseconds(2000);
     digitalWrite(9, LOW);
     delay(50);
     }
   }
