int whileloop(void);
int forloop(void);
int recursion(void);