#include <stdio.h>
#include <stdlib.h>
#include "problem.h"


int main(){

printf("summan av falt: %d\n\n", whileloop());
printf("summan av falt: %d\n\n", forloop());
printf("summan av falt: %d\n\n", recursion());

return 0;
}