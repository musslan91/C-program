#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "problem2.h"

int main(){

	printf("%d\n\n", falt());//Skriver ut funktion.

	return 0;
}