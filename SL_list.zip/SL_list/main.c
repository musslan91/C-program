#include <stdio.h>
#include <stdlib.h>

typedef struct _SL_list_S {
   int content;
   struct _SL_list_S *next;
} SL_list;

int is_empty(SL_list *LL) {
   if(LL == 0) return 1; else return 0;
}

SL_list *insert_first(int val, SL_list *LL) {
   SL_list *res = (SL_list *)malloc(sizeof(SL_list));
   /* (*res).content = val;
      (*res).next = LL; */
   res->content = val;
   res->next = LL;
   return res;
}

void print_LL(SL_list *LL) {
   if(LL == 0) printf("NULL\n");
}

int main(void) {
   SL_list *LL = 0;
   print_LL(LL);
   printf("LL == %d\n", is_empty(LL));
   
   return 0;
}
