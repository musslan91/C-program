//dht22pi, 14/12-2017
//Marcus Arvidsson programmer
//Läser te
//read temperature and humidity from DHT11 or DHT22 sensor
 
//#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h> 

	int data[5] = { 0, 0, 0, 0, 0 };
      uint8_t laststate	= HIGH;
      uint8_t counter		= 0;
      uint8_t j			= 0, i;

      data[0] = data[1] = data[2] = data[3] = data[4] = 0;

// stub/driver functions not fully developed yet
void delay(int a){
}

void pinMode() {
  
}

int wiringPiSetup() {
  return 0;
}

void delayMicroseconds(int s1 ) {
}
			
int digitalRead(int a){
  return 0;
}

void digitalWrite(int a, int b){

}


int main( void )
{
  printf( "Raspberry Pi DHT11/DHT22 temperature/humidity test\n" );

  if ( wiringPiSetup() == -1 ){
    exit( 1 );
}

  while ( 1 )
    {
      /* pull pin down for 18 milliseconds */
      pinMode( DHT_PIN, OUTPUT );

      digitalWrite( DHT_PIN, LOW );
      delay( 18 );

      /* prepare to read the pin */
      pinMode( DHT_PIN, INPUT );

      /* detect change and read data */
      	detect();
      /*
       * check we read 40 bits (8bit x 5 ) + verify checksum in the last byte
       * print it out if data is good
       */
    	checksum();

	else 
	{
	printf( "Data not good, skip\n" );
     }
		delay( 2000 ); /* wait 2 seconds before next read */
	}

	return(0);
}
