// stub/driver functions not fully developed yet
// Declarations
void delay(int a);
void pinMode();
int wiringPiSetup();
void delayMicroseconds(int s1 );			
int digitalRead(int a);
void digitalWrite(int a, int b);
void detect(void);
void checksum(void);
