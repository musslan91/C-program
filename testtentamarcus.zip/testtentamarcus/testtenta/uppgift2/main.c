#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>

int main()
{

	char personnummer[11];
	long long int kon, kille = 0, tjej = 1;

	printf("Skriv personnummer\n");
    scanf("%c\n", &personnummer);

    kon = kon / 10;

   for(int i = 0; personnummer[1] <= 11; i++)
   {

	if(personnummer[7] == '+' || personnummer[7] == '-' && kon %2 == kille)
	{
		printf("Okej personnummer\n");
		printf("Du är man\n");

		if(personnummer[7] == '+' || personnummer[7] =='-' && kon %2 == tjej)
		{

			printf("Okej personnummer\n");
			printf("Du är kvinna\n");
		}
	}
}

    return 0;
}
